def column_to_ordinal(column_name):
    ordinal_value = 0
    column_name = column_name.upper()
    
    for char in column_name:
        char_value = ord(char) - ord('A') + 1
        ordinal_value = ordinal_value * 26 + char_value
    
    return ordinal_value

if __name__ == "__main__":
    print(column_to_ordinal('a'))   
    print(column_to_ordinal('aa'))
